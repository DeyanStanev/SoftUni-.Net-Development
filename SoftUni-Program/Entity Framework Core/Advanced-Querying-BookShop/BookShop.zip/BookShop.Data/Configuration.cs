﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=(localdb)\MSSQLLocalDB;Database=SoftUni;Integrated Security=True;";
    }
}
