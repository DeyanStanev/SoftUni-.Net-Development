﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DtoModels.InputDto
{
    public class CategoryInputDto
    {
        public string Name { get; set; }

    }
}
